from django.shortcuts import render
from .forms import ContactForm

def contact_view(request):
    form = ContactForm(request.POST or None)
    if form.is_valid():
        name = form.cleaned_data['name']
        email = form.cleaned_data['email']
        message = form.cleaned_data['message']
        return render(request, "form_app/success.html", {"name": name})
    return render(request, "form_app/contact.html", {"form": form})
