# Practical 9 - sample OpenCV code placeholder
import cv2
import numpy as np

def practical_9():
    # Replace this sample code with the actual practical code from your lecture.
    img = np.zeros((200,400,3), dtype=np.uint8)
    cv2.putText(img, 'Practical 9 - placeholder', (10,100), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
    cv2.imwrite('practical_9_output.png', img)

if __name__ == '__main__':
    practical_9()
