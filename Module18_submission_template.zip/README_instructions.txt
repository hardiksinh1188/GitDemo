Module 18 - OpenCV module Implementations
Template package generated on 2025-09-16 09:15:11

What this package contains (template/placeholders):
- code/ : contains sample placeholder .py files for each practical (practical_1.py ... practical_12.py)
- screenshots/ : contains placeholder images for each practical. YOU MUST REPLACE THESE with your actual unedited screenshots.
- compiled_submission.pdf : a PDF that compiles each placeholder screenshot and the corresponding placeholder code (for preview).
- README_instructions.txt : this file.

Important: I CANNOT create real, unedited screenshots of your system output or timestamps. You must provide those screenshots yourself.
Follow these steps to complete the submission:
1. For each practical:
   a. Run the practical code on your own system and capture a COMPLETE, UNEDITED screenshot that shows:
      - The FULL code you executed (no cropping)
      - The output displayed on your system
      - Your system timestamp (visible on-screen)
   b. Save the screenshot as practical_<n>_screenshot.png (replace the placeholder image in screenshots/).
2. (Optional) If you want me to re-generate the final PDF that merges your actual screenshots into compiled_submission.pdf, upload the screenshots here or allow me access to them and ask me to rebuild the PDF.
3. Before zipping, verify screenshots are in order and named practical_1_screenshot.png ... practical_12_screenshot.png
4. Zip the folder or upload compiled_submission.pdf to Google Drive and share the accessible link.

Checklist (required in your submission):
- All lectures completed
- All practical exercises implemented
- Full, unedited screenshots for each practical (code + output + timestamp visible)
- Screenshots organized in sequence
- Final ZIP or PDF uploaded to Drive with sharing enabled

If you want, I can:
- Rebuild compiled_submission.pdf using your uploaded screenshots (so it becomes a proper submission PDF).
- Create a final ZIP containing the updated PDF and code files.
