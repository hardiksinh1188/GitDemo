# flask-authentication-system


# Login page
![alt text](https://github.com/kritimyantra/flask-authentication-system/blob/main/login.png?raw=true)


# Register page
![alt text](https://github.com/kritimyantra/flask-authentication-system/blob/main/register.png?raw=true)


# Dashboard page
![alt text](https://github.com/kritimyantra/flask-authentication-system/blob/main/dashboard.png?raw=true)
