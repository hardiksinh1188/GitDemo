# Task 1: Basic Mathematical Operations

# Taking two numbers as input
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

# Performing operations
addition = num1 + num2
subtraction = num1 - num2
multiplication = num1 * num2

# Division with check for divide by zero
if num2 != 0:
    division = num1 / num2
else:
    division = "Undefined (cannot divide by zero)"

# Displaying results
print("\nResults:")
print(f"Addition: {num1} + {num2} = {addition}")
print(f"Subtraction: {num1} - {num2} = {subtraction}")
print(f"Multiplication: {num1} * {num2} = {multiplication}")
print(f"Division: {num1} / {num2} = {division}")



# Task 2: Personalized Greeting

# Taking user input for first and last name
first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

# Concatenating to form full name
full_name = first_name + " " + last_name

# Displaying greeting
print(f"\nHello, {full_name}! Welcome to Python programming.")
