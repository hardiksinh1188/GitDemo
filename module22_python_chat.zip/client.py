# client.py
import socket
import threading
import sys

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 5000

def receive_messages(sock):
    try:
        while True:
            data = sock.recv(4096)
            if not data:
                print("[!] Disconnected from server.")
                break
            sys.stdout.write(data.decode('utf-8'))
            sys.stdout.flush()
    except ConnectionResetError:
        print("\n[!] Connection closed by server.")
    except Exception as e:
        print(f"\n[!] Receive error: {e}")
    finally:
        sock.close()
        os._exit(0)

def send_messages(sock):
    try:
        while True:
            msg = sys.stdin.readline()
            if not msg:
                continue
            sock.sendall(msg.encode('utf-8'))
    except BrokenPipeError:
        print("[!] Connection lost.")
    except Exception as e:
        print(f"[!] Send error: {e}")
    finally:
        sock.close()

if __name__ == "__main__":
    import os
    nickname = input("Enter your nickname: ").strip()
    if nickname == "":
        nickname = "Anonymous"
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((SERVER_HOST, SERVER_PORT))
    except Exception as e:
        print(f"[!] Could not connect to server at {SERVER_HOST}:{SERVER_PORT} -> {e}")
        sys.exit(1)
    sock.sendall((nickname + "\n").encode('utf-8'))

    recv_thread = threading.Thread(target=receive_messages, args=(sock,), daemon=True)
    recv_thread.start()

    print(f"[+] Connected to {SERVER_HOST}:{SERVER_PORT} as {nickname}. Type messages and press Enter.")
    try:
        send_messages(sock)
    except KeyboardInterrupt:
        print("\n[!] Exiting client.")
        sock.close()
        sys.exit(0)
