# server.py
import socket
import threading

HOST = '0.0.0.0'
PORT = 5000

clients = []
nicknames = []

lock = threading.Lock()

def broadcast(message, sender_sock=None):
    with lock:
        for client in clients:
            try:
                if client is not sender_sock:
                    client.sendall(message)
            except:
                pass

def handle_client(client, addr):
    print(f"[+] New connection from {addr}")
    try:
        nickname = client.recv(1024).decode('utf-8', errors='ignore').strip()
        if not nickname:
            nickname = f"User{addr[1]}"
        with lock:
            nicknames.append(nickname)
        welcome = f"[SERVER] {nickname} joined the chat.".encode('utf-8')
        broadcast(welcome, sender_sock=None)
        client.sendall(b"[SERVER] Welcome! Type messages and press Enter to send.\n")
        while True:
            message = client.recv(4096)
            if not message:
                break
            formatted = f"{nickname}: ".encode('utf-8') + message
            broadcast(formatted, sender_sock=client)
    except ConnectionResetError:
        pass
    finally:
        with lock:
            if client in clients:
                idx = clients.index(client)
                clients.remove(client)
                try:
                    left_nick = nicknames.pop(idx)
                except:
                    left_nick = "Unknown"
        client.close()
        left_msg = f"[SERVER] {left_nick} left the chat.".encode('utf-8')
        broadcast(left_msg, sender_sock=None)
        print(f"[-] Connection closed: {addr}")

def start_server():
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.bind((HOST, PORT))
    server_sock.listen(10)
    print(f"[+] Server listening on {HOST}:{PORT}")
    try:
        while True:
            client, addr = server_sock.accept()
            with lock:
                clients.append(client)
            thread = threading.Thread(target=handle_client, args=(client, addr), daemon=True)
            thread.start()
    except KeyboardInterrupt:
        print("\n[!] Server shutting down...")
    finally:
        server_sock.close()

if __name__ == "__main__":
    start_server()
