# Python Chat App (Module 22)

## Files
- `server.py` — chat server (multi-client, thread-based)
- `client.py` — chat client (terminal)

## Requirements
- Python 3.7+
- No external packages

## Run
1. Open terminal and start server:
   ```bash
   python server.py
   ```
2. In separate terminal(s) start one or more clients:
   ```bash
   python client.py
   ```
   Enter a nickname when prompted.

## Demo steps to record
- Show code in editor/IDE.
- Start server and show the terminal output.
- Start at least 2 clients and demonstrate sending messages between them.
- Show server printing connection logs and broadcast messages.
