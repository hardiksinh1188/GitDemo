# Facebook Auto Blog Poster (Selenium Project)

This project automates posting a blog/status update on Facebook using Selenium.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Update your Facebook email & password inside `main.py`.

3. Run the script:
   ```bash
   python main.py
   ```

⚠️ Use a **test account**, not your main Facebook account.
