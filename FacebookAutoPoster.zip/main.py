from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

# Facebook credentials (use test account for safety!)
FB_EMAIL = "your_email"
FB_PASSWORD = "your_password"
BLOG_CONTENT = "This is an automated post created using Selenium!"

def facebook_login_and_post():
    # Setup Chrome browser
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.maximize_window()

    # Open Facebook
    driver.get("https://www.facebook.com/")
    time.sleep(3)

    # Login
    email_box = driver.find_element(By.ID, "email")
    email_box.send_keys(FB_EMAIL)

    password_box = driver.find_element(By.ID, "pass")
    password_box.send_keys(FB_PASSWORD)
    password_box.send_keys(Keys.RETURN)

    time.sleep(5)  # wait for login

    # Create a post
    post_box = driver.find_element(By.XPATH, "//span[text()=\"What's on your mind, \"]/ancestor::div[@role='button']")
    post_box.click()
    time.sleep(3)

    # Enter blog content
    active_box = driver.find_element(By.XPATH, "//div[@role='textbox']")
    active_box.send_keys(BLOG_CONTENT)
    time.sleep(2)

    # Post
    post_button = driver.find_element(By.XPATH, "//div[@aria-label='Post']")
    post_button.click()

    print("✅ Blog posted successfully!")
    time.sleep(5)
    driver.quit()

if __name__ == "__main__":
    facebook_login_and_post()
