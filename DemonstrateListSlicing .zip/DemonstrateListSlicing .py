# Task 2: Demonstrate List Slicing

# 1. Create a list of numbers from 1 to 10
numbers = list(range(1, 11))

# 2. Extract the first five elements
first_five = numbers[:5]

# 3. Reverse these extracted elements
reversed_list = first_five[::-1]

# 4. Print both the extracted list and the reversed list
print("Extracted List:", first_five)
print("Reversed List:", reversed_list)
