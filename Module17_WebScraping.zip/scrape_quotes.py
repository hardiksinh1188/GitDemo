import requests
from bs4 import BeautifulSoup

url = "http://quotes.toscrape.com/"
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

quotes = []
for q in soup.find_all("span", class_="text"):
    quotes.append(q.get_text())

with open("quotes.txt", "w", encoding="utf-8") as f:
    for quote in quotes:
        f.write(quote + "\n")

print("Quotes saved to quotes.txt")
