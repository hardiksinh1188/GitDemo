import requests
import pandas as pd
from bs4 import BeautifulSoup

url = "https://www.worldometers.info/world-population/population-by-country/"
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

table = soup.find("table", id="example2")
rows = table.find_all("tr")

data = []
for row in rows[1:]:
    cols = [c.text.strip() for c in row.find_all("td")]
    if cols:
        data.append(cols)

df = pd.DataFrame(data, columns=[
    "Country", "Population (2023)", "Yearly Change", "Net Change", 
    "Density (P/Km²)", "Land Area (Km²)", "Migrants (net)", 
    "Fert. Rate", "Med. Age", "Urban Pop %", "World Share"
])
df.to_csv("population.csv", index=False)
print("Population data saved to population.csv")
