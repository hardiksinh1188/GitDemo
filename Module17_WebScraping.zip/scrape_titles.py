import requests
from bs4 import BeautifulSoup

url = "https://news.ycombinator.com/"
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

titles = [t.get_text() for t in soup.find_all("a", class_="storylink")]

with open("titles.txt", "w", encoding="utf-8") as f:
    for title in titles:
        f.write(title + "\n")

print("News titles saved to titles.txt")
