Module 17: Web Scraping Project

This folder contains example practicals for web scraping:

1. scrape_quotes.py  -> Scrapes quotes from http://quotes.toscrape.com/ and saves to quotes.txt
2. scrape_titles.py  -> Scrapes news titles from Hacker News and saves to titles.txt
3. scrape_table.py   -> Scrapes population table from worldometers and saves to population.csv

Run using: python filename.py
Make sure to install dependencies: requests, beautifulsoup4, pandas
