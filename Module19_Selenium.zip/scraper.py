from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import csv

# Initialize the browser
driver = webdriver.Chrome()

# Open website
driver.get("https://quotes.toscrape.com/")
time.sleep(2)

# Extract quotes and authors
quotes = driver.find_elements(By.CLASS_NAME, "text")
authors = driver.find_elements(By.CLASS_NAME, "author")

data = []
for q, a in zip(quotes, authors):
    data.append([q.text, a.text])

# Save to CSV
with open("quotes.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["Quote", "Author"])
    writer.writerows(data)

driver.quit()
