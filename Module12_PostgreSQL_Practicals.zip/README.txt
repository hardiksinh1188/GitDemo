Replace the .txt placeholders with your actual screenshots (.png/.jpg).
Keep the same file names for correct order.
